This file contains everything needed to instll WIT ROV on a windows machine.

All you need to do is run install.exe